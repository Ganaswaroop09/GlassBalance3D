/**
 * Glass Balance 3D - Glass Bridge Course & Movement System
 * Input-driven movement system with exact zero-drift and safe touch release
 */

(function () {
  'use strict';

  // --- AUDIO SYNTHESIZER ---
  class SoundManager {
    constructor() {
      this.ctx = null;
      this.initOnFirstTouch = false;
    }

    init() {
      if (this.ctx) return;
      try {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        this.ctx = new AudioCtx();
      } catch (e) {}
    }

    playRoll() {
      // Subtle roll click
    }

    playCheckpoint() {
      if (!this.ctx) return;
      try {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, this.ctx.currentTime); // D5
        osc.frequency.exponentialRampToValueAtTime(880, this.ctx.currentTime + 0.25); // A5
        gain.gain.setValueAtTime(0.2, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.3);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        osc.stop(this.ctx.currentTime + 0.3);
      } catch (e) {}
    }

    playFall() {
      if (!this.ctx) return;
      try {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(320, this.ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(60, this.ctx.currentTime + 0.45);
        gain.gain.setValueAtTime(0.25, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.5);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        osc.stop(this.ctx.currentTime + 0.5);
      } catch (e) {}
    }

    playVictory() {
      if (!this.ctx) return;
      try {
        [523.25, 659.25, 783.99, 1046.5].forEach((freq, idx) => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.value = freq;
          const start = this.ctx.currentTime + idx * 0.1;
          gain.gain.setValueAtTime(0.2, start);
          gain.gain.exponentialRampToValueAtTime(0.001, start + 0.45);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start(start);
          osc.stop(start + 0.45);
        });
      } catch (e) {}
    }
  }

  // --- COURSE / LEVEL TRACK DEFINITIONS ---
  // Each course defines total distance, max forward speed, bridge width, segments, gaps, and checkpoints.
  const COURSES = [
    {
      id: 1,
      name: 'Crystal Highway',
      speed: 7.5,
      totalLength: 120,
      width: 4.2,
      checkpoints: [35, 75],
      // Gaps: array of { sStart, sEnd, laneStart, laneEnd }
      gaps: [
        { sStart: 48, sEnd: 56, laneStart: -2.1, laneEnd: -0.2 }, // Left side gap
        { sStart: 88, sEnd: 96, laneStart: 0.2, laneEnd: 2.1 }    // Right side gap
      ],
      // Waypoints defining curvature: (s, curvatureKappa, dY)
      curveAt: (s) => {
        // Subtle straight course with gentle S-bend near s=60..75
        if (s > 55 && s < 75) {
          return Math.sin(((s - 55) / 20) * Math.PI) * 0.25;
        }
        return 0;
      }
    },
    {
      id: 2,
      name: 'Emerald Overpass',
      speed: 8.0,
      totalLength: 140,
      width: 3.8,
      checkpoints: [40, 85],
      gaps: [
        { sStart: 25, sEnd: 32, laneStart: -1.9, laneEnd: -0.1 },
        { sStart: 55, sEnd: 63, laneStart: -0.6, laneEnd: 0.6 },  // Center gap
        { sStart: 105, sEnd: 114, laneStart: 0.2, laneEnd: 1.9 }
      ],
      curveAt: (s) => {
        if (s > 35 && s < 60) return 0.35; // Turn right
        if (s > 75 && s < 100) return -0.35; // Turn left
        return 0;
      }
    },
    {
      id: 3,
      name: 'Sapphire Skyline',
      speed: 8.5,
      totalLength: 160,
      width: 3.5,
      checkpoints: [45, 95],
      gaps: [
        { sStart: 30, sEnd: 38, laneStart: 0.1, laneEnd: 1.75 },
        { sStart: 60, sEnd: 68, laneStart: -1.75, laneEnd: -0.1 },
        { sStart: 115, sEnd: 125, laneStart: -0.7, laneEnd: 0.7 }
      ],
      curveAt: (s) => {
        if (s > 25 && s < 50) return -0.4;
        if (s > 70 && s < 100) return 0.45;
        return 0;
      }
    },
    {
      id: 4,
      name: 'The Glass Apex',
      speed: 9.0,
      totalLength: 180,
      width: 3.2,
      checkpoints: [50, 110],
      gaps: [
        { sStart: 30, sEnd: 38, laneStart: -1.6, laneEnd: 0 },
        { sStart: 70, sEnd: 79, laneStart: 0, laneEnd: 1.6 },
        { sStart: 125, sEnd: 135, laneStart: -0.6, laneEnd: 0.6 },
        { sStart: 150, sEnd: 160, laneStart: -1.6, laneEnd: -0.2 }
      ],
      curveAt: (s) => {
        return Math.sin(s * 0.04) * 0.3;
      }
    }
  ];

  // --- GAME WORLD CLASS ---
  class GameWorld {
    constructor() {
      this.sound = new SoundManager();
      this.container = document.getElementById('canvas-container');

      this.currentLevelIndex = 0;
      this.course = COURSES[this.currentLevelIndex];

      // Input Controls Set - tracks active pressed directions: 'up', 'down', 'left', 'right'
      this.controls = new Set();

      // State initialized safely
      this.state = this.createState();

      // Active checkpoint for respawning
      this.lastCheckpointS = 0;

      // Three.js instances
      this.scene = null;
      this.camera = null;
      this.renderer = null;

      // 3D Meshes
      this.ballMesh = null;
      this.ballRadius = 0.5;
      this.bridgeGroup = null;
      this.checkpointMarkers = [];

      this.initThree();
      this.initCourse3D();
      this.initDOM();
      this.initInputListeners();

      this.startLevel(0);
    }

    createState() {
      return {
        s: 0,
        lane: 0,
        forwardSpeed: 0,
        sideSpeed: 0,
        isFalling: false,
        fallVelocity: 0,
        fallY: 0,
        score: 0,
        completed: false,
        activeCheckpoints: new Set()
      };
    }

    // --- THREE.JS INITIALIZATION ---
    initThree() {
      const width = window.innerWidth;
      const height = window.innerHeight;

      this.scene = new THREE.Scene();
      // Bright sky background and atmospheric horizon haze
      this.scene.background = new THREE.Color(0xBAE6FD);
      this.scene.fog = new THREE.FogExp2(0xCBE8FA, 0.0055);

      this.camera = new THREE.PerspectiveCamera(52, width / height, 0.1, 400);
      this.camera.position.set(0, 5, -8);

      this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
      this.renderer.setSize(width, height);
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      this.renderer.shadowMap.enabled = true;
      this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      this.container.appendChild(this.renderer.domElement);

      // Natural Sky Hemisphere Light (bright blue sky above, soft cloud bounce from below)
      const hemiLight = new THREE.HemisphereLight(0x7DD3FC, 0xFFFFFF, 0.95);
      this.scene.add(hemiLight);

      // Soft Natural Sunlight illuminating the glass platforms and ball
      const sunLight = new THREE.DirectionalLight(0xFFFBEB, 1.45);
      sunLight.position.set(28, 48, 30);
      sunLight.castShadow = true;
      sunLight.shadow.mapSize.width = 1024;
      sunLight.shadow.mapSize.height = 1024;
      sunLight.shadow.camera.near = 0.5;
      sunLight.shadow.camera.far = 100;
      sunLight.shadow.camera.left = -22;
      sunLight.shadow.camera.right = 22;
      sunLight.shadow.camera.top = 22;
      sunLight.shadow.camera.bottom = -22;
      sunLight.shadow.bias = -0.0004;
      this.scene.add(sunLight);

      // Gentle ambient fill
      const ambientLight = new THREE.AmbientLight(0xE0F2FE, 0.45);
      this.scene.add(ambientLight);

      // 3D Procedural Sky Dome and Floating Clouds Environment
      this.createSkyAndClouds();

      // Glass Ball creation
      this.createGlassBall();

      // Ambient Dust Particles (sunlit air motes)
      this.createAmbientDust();
    }

    createSkyAndClouds() {
      // 1. PROCEDURAL 3D SKY DOME (NATURAL VERTICAL GRADIENT)
      const skyCanvas = document.createElement('canvas');
      skyCanvas.width = 512;
      skyCanvas.height = 512;
      const skyCtx = skyCanvas.getContext('2d');

      // Gradient from deep azure zenith to soft light blue horizon and hazy base
      const grad = skyCtx.createLinearGradient(0, 0, 0, 512);
      grad.addColorStop(0.0, '#1E40AF'); // Deep vibrant royal blue at zenith
      grad.addColorStop(0.25, '#0284C7'); // Rich sky blue
      grad.addColorStop(0.55, '#38BDF8'); // Bright cerulean
      grad.addColorStop(0.78, '#BAE6FD'); // Soft light blue near horizon
      grad.addColorStop(0.92, '#E0F2FE'); // Atmospheric white-cyan horizon haze
      grad.addColorStop(1.0, '#F0F9FF'); // Gentle mist base
      skyCtx.fillStyle = grad;
      skyCtx.fillRect(0, 0, 512, 512);

      // Soft radiant sun disc painted into the sky dome
      const sunGrad = skyCtx.createRadialGradient(380, 110, 0, 380, 110, 85);
      sunGrad.addColorStop(0.0, 'rgba(255, 255, 240, 1.0)');
      sunGrad.addColorStop(0.2, 'rgba(254, 243, 199, 0.85)');
      sunGrad.addColorStop(0.5, 'rgba(253, 230, 138, 0.35)');
      sunGrad.addColorStop(1.0, 'rgba(253, 230, 138, 0.0)');
      skyCtx.fillStyle = sunGrad;
      skyCtx.beginPath();
      skyCtx.arc(380, 110, 85, 0, Math.PI * 2);
      skyCtx.fill();

      const skyTexture = new THREE.CanvasTexture(skyCanvas);
      const skyGeo = new THREE.SphereGeometry(260, 32, 20);
      const skyMat = new THREE.MeshBasicMaterial({
        map: skyTexture,
        side: THREE.BackSide,
        depthWrite: false
      });
      this.skyDome = new THREE.Mesh(skyGeo, skyMat);
      this.scene.add(this.skyDome);

      // 2. PROCEDURAL SOFT CLOUD SPRITE TEXTURE
      const cloudCanvas = document.createElement('canvas');
      cloudCanvas.width = 128;
      cloudCanvas.height = 128;
      const cloudCtx = cloudCanvas.getContext('2d');

      // Overlapping soft feathery radial puffs creating realistic billowy volume
      const drawPuff = (cx, cy, r, alpha) => {
        const pGrad = cloudCtx.createRadialGradient(cx, cy, 0, cx, cy, r);
        pGrad.addColorStop(0.0, `rgba(255, 255, 255, ${alpha})`);
        pGrad.addColorStop(0.4, `rgba(248, 250, 252, ${alpha * 0.75})`);
        pGrad.addColorStop(0.75, `rgba(240, 249, 255, ${alpha * 0.25})`);
        pGrad.addColorStop(1.0, 'rgba(240, 249, 255, 0.0)');
        cloudCtx.fillStyle = pGrad;
        cloudCtx.beginPath();
        cloudCtx.arc(cx, cy, r, 0, Math.PI * 2);
        cloudCtx.fill();
      };

      drawPuff(64, 64, 58, 0.9);
      drawPuff(46, 56, 44, 0.85);
      drawPuff(82, 58, 44, 0.85);
      drawPuff(52, 74, 40, 0.8);
      drawPuff(76, 74, 40, 0.8);

      this.cloudTexture = new THREE.CanvasTexture(cloudCanvas);

      // Shared cloud material with soft transparency
      this.cloudMaterial = new THREE.SpriteMaterial({
        map: this.cloudTexture,
        color: 0xFFFFFF,
        transparent: true,
        opacity: 0.82,
        depthWrite: false
      });

      this.cloudDeckMaterial = new THREE.SpriteMaterial({
        map: this.cloudTexture,
        color: 0xF8FAFC,
        transparent: true,
        opacity: 0.88,
        depthWrite: false
      });

      this.cloudObjects = [];

      // A) EXTENSIVE SEA OF CLOUDS (Deck floating below the bridge at Y = -16 to -10)
      // Makes the glass platforms look like they are floating high above the clouds
      const deckCount = 55;
      for (let i = 0; i < deckCount; i++) {
        const sprite = new THREE.Sprite(this.cloudDeckMaterial);
        const x = (Math.random() - 0.5) * 160;
        const y = -14 + Math.random() * 4.5;
        const z = -40 + Math.random() * 260;
        const scale = 22 + Math.random() * 26;

        sprite.position.set(x, y, z);
        sprite.scale.set(scale, scale * 0.65, 1);
        this.scene.add(sprite);

        this.cloudObjects.push({
          sprite: sprite,
          vx: 0.25 + Math.random() * 0.25,
          vz: 0.12 + Math.random() * 0.18,
          baseY: y,
          phase: Math.random() * Math.PI * 2,
          isDeck: true
        });
      }

      // B) SOFT FLUFFY FLOATING CLOUD FORMATIONS AT DIFFERENT HEIGHTS AND DISTANCES
      const cloudClustersCount = 38;
      for (let i = 0; i < cloudClustersCount; i++) {
        const clusterGroup = new THREE.Group();
        const lateralDist = (Math.random() < 0.5 ? -1 : 1) * (18 + Math.random() * 75);
        const heightLevel = -5 + Math.random() * 32; // Low, mid, and high altitude clouds
        const zPos = -40 + Math.random() * 260;

        // Group 3 to 5 overlapping billowy puffs to form each distinct 3D cloud
        const puffsInCluster = 3 + Math.floor(Math.random() * 3);
        const baseScale = 14 + Math.random() * 20;

        for (let p = 0; p < puffsInCluster; p++) {
          const pSprite = new THREE.Sprite(this.cloudMaterial);
          const offsetX = (Math.random() - 0.5) * baseScale * 0.5;
          const offsetY = (Math.random() - 0.5) * baseScale * 0.25;
          const offsetZ = (Math.random() - 0.5) * baseScale * 0.4;
          const puffScale = baseScale * (0.75 + Math.random() * 0.45);

          pSprite.position.set(offsetX, offsetY, offsetZ);
          pSprite.scale.set(puffScale, puffScale * 0.68, 1);
          clusterGroup.add(pSprite);
        }

        clusterGroup.position.set(lateralDist, heightLevel, zPos);
        this.scene.add(clusterGroup);

        this.cloudObjects.push({
          sprite: clusterGroup,
          vx: 0.35 + Math.random() * 0.35,
          vz: 0.15 + Math.random() * 0.25,
          baseY: heightLevel,
          phase: Math.random() * Math.PI * 2,
          isDeck: false
        });
      }

      // 3. SUBTLE OPTICAL SUN-FLARE EFFECT
      this.createSunFlare();
    }

    createSunFlare() {
      this.sunOffset = new THREE.Vector3(75, 125, 80);
      this.sunFlareGroup = new THREE.Group();
      this.scene.add(this.sunFlareGroup);

      // A) Primary Sun Glow Disc Canvas
      const discCanvas = document.createElement('canvas');
      discCanvas.width = 128;
      discCanvas.height = 128;
      const discCtx = discCanvas.getContext('2d');
      const discGrad = discCtx.createRadialGradient(64, 64, 0, 64, 64, 64);
      discGrad.addColorStop(0.0, 'rgba(255, 255, 252, 1.0)');
      discGrad.addColorStop(0.2, 'rgba(254, 240, 138, 0.7)');
      discGrad.addColorStop(0.5, 'rgba(251, 191, 36, 0.22)');
      discGrad.addColorStop(1.0, 'rgba(251, 191, 36, 0.0)');
      discCtx.fillStyle = discGrad;
      discCtx.fillRect(0, 0, 128, 128);
      const discTexture = new THREE.CanvasTexture(discCanvas);

      // B) Anamorphic Horizontal Sunlight Streak Canvas
      const streakCanvas = document.createElement('canvas');
      streakCanvas.width = 256;
      streakCanvas.height = 64;
      const streakCtx = streakCanvas.getContext('2d');
      const streakGrad = streakCtx.createRadialGradient(128, 32, 0, 128, 32, 120);
      streakGrad.addColorStop(0.0, 'rgba(255, 250, 220, 0.6)');
      streakGrad.addColorStop(0.3, 'rgba(254, 243, 199, 0.3)');
      streakGrad.addColorStop(0.7, 'rgba(186, 230, 253, 0.1)');
      streakGrad.addColorStop(1.0, 'rgba(186, 230, 253, 0.0)');
      streakCtx.fillStyle = streakGrad;
      streakCtx.fillRect(0, 0, 256, 64);
      const streakTexture = new THREE.CanvasTexture(streakCanvas);

      // C) Subtle Aperture Halo Ring Canvas
      const ringCanvas = document.createElement('canvas');
      ringCanvas.width = 128;
      ringCanvas.height = 128;
      const ringCtx = ringCanvas.getContext('2d');
      const ringGrad = ringCtx.createRadialGradient(64, 64, 40, 64, 64, 62);
      ringGrad.addColorStop(0.0, 'rgba(251, 191, 36, 0.0)');
      ringGrad.addColorStop(0.5, 'rgba(254, 243, 199, 0.25)');
      ringGrad.addColorStop(0.8, 'rgba(56, 189, 248, 0.12)');
      ringGrad.addColorStop(1.0, 'rgba(56, 189, 248, 0.0)');
      ringCtx.fillStyle = ringGrad;
      ringCtx.fillRect(0, 0, 128, 128);
      const ringTexture = new THREE.CanvasTexture(ringCanvas);

      // D) Soft Bokeh Ghost Disc Canvas
      const ghostCanvas = document.createElement('canvas');
      ghostCanvas.width = 64;
      ghostCanvas.height = 64;
      const ghostCtx = ghostCanvas.getContext('2d');
      const ghostGrad = ghostCtx.createRadialGradient(32, 32, 0, 32, 32, 32);
      ghostGrad.addColorStop(0.0, 'rgba(254, 243, 199, 0.32)');
      ghostGrad.addColorStop(0.6, 'rgba(56, 189, 248, 0.15)');
      ghostGrad.addColorStop(1.0, 'rgba(56, 189, 248, 0.0)');
      ghostCtx.fillStyle = ghostGrad;
      ghostCtx.fillRect(0, 0, 64, 64);
      const ghostTexture = new THREE.CanvasTexture(ghostCanvas);

      // Main Sun Corona Flare
      this.sunMainMat = new THREE.SpriteMaterial({
        map: discTexture,
        blending: THREE.AdditiveBlending,
        transparent: true,
        opacity: 0.65,
        depthWrite: false,
        depthTest: false
      });
      this.sunMainSprite = new THREE.Sprite(this.sunMainMat);
      this.sunMainSprite.scale.set(48, 48, 1);
      this.sunFlareGroup.add(this.sunMainSprite);

      // Horizontal Sunbeam Streak
      this.sunStreakMat = new THREE.SpriteMaterial({
        map: streakTexture,
        blending: THREE.AdditiveBlending,
        transparent: true,
        opacity: 0.38,
        depthWrite: false,
        depthTest: false
      });
      this.sunStreakSprite = new THREE.Sprite(this.sunStreakMat);
      this.sunStreakSprite.scale.set(88, 14, 1);
      this.sunFlareGroup.add(this.sunStreakSprite);

      // Ghost Elements along optical axis
      this.ghostElements = [];
      const ghostConfigs = [
        { tex: ringTexture, scale: 22, factor: 0.35, baseAlpha: 0.22 },
        { tex: ghostTexture, scale: 12, factor: 0.65, baseAlpha: 0.18 },
        { tex: ghostTexture, scale: 18, factor: 0.95, baseAlpha: 0.14 },
        { tex: ringTexture, scale: 30, factor: 1.35, baseAlpha: 0.15 }
      ];

      ghostConfigs.forEach(cfg => {
        const mat = new THREE.SpriteMaterial({
          map: cfg.tex,
          blending: THREE.AdditiveBlending,
          transparent: true,
          opacity: 0.0,
          depthWrite: false,
          depthTest: false
        });
        const sprite = new THREE.Sprite(mat);
        sprite.scale.set(cfg.scale, cfg.scale, 1);
        this.scene.add(sprite);
        this.ghostElements.push({
          sprite: sprite,
          mat: mat,
          factor: cfg.factor,
          baseAlpha: cfg.baseAlpha
        });
      });

      this.sunFlareCurrentOpacity = 0.65;
    }

    updateSunFlare(dt) {
      if (!this.sunFlareGroup || !this.camera) return;

      // Position main sun flare in direction of sunlight relative to camera
      const sunWorldPos = this.camera.position.clone().add(this.sunOffset);
      this.sunFlareGroup.position.copy(sunWorldPos);

      // Project sun position to Normalized Device Coordinates (NDC: -1 to 1)
      const proj = sunWorldPos.clone().project(this.camera);

      // Check if sun is in front of the camera
      const inFront = proj.z < 1.0;
      const distFromCenter = Math.sqrt(proj.x * proj.x + proj.y * proj.y);

      // Flare visibility: strongest when facing near the sun, soft fade at perimeter
      let targetOpacity = 0.0;
      if (inFront && distFromCenter < 2.5) {
        targetOpacity = Math.max(0.0, (1.0 - distFromCenter / 2.5) * 0.75);
      }

      this.sunFlareCurrentOpacity += (targetOpacity - this.sunFlareCurrentOpacity) * Math.min(1.0, dt * 5.0);

      this.sunMainMat.opacity = this.sunFlareCurrentOpacity;
      this.sunStreakMat.opacity = this.sunFlareCurrentOpacity * 0.65;

      // Update secondary ghost flare elements along optical axis from sun through camera center
      const camDir = new THREE.Vector3();
      this.camera.getWorldDirection(camDir);
      const camTarget = this.camera.position.clone().add(camDir.multiplyScalar(this.sunOffset.length()));

      for (let i = 0; i < this.ghostElements.length; i++) {
        const g = this.ghostElements[i];
        const ghostPos = new THREE.Vector3().lerpVectors(sunWorldPos, camTarget, g.factor);
        g.sprite.position.copy(ghostPos);
        g.mat.opacity = this.sunFlareCurrentOpacity * (g.baseAlpha / 0.75);
      }
    }

    updateSkyAndClouds(dt, time) {
      if (!this.skyDome) return;

      // Keep Sky Dome centered around camera horizontally for infinite horizon depth
      this.skyDome.position.x = this.camera.position.x;
      this.skyDome.position.z = this.camera.position.z;

      const ballPos = this.ballMesh ? this.ballMesh.position : new THREE.Vector3(0, 0, 0);

      // Smooth, slow drift of all cloud formations
      for (let i = 0; i < this.cloudObjects.length; i++) {
        const c = this.cloudObjects[i];

        c.sprite.position.x += c.vx * dt;
        c.sprite.position.z += c.vz * dt;
        c.sprite.position.y = c.baseY + Math.sin(time * 0.35 + c.phase) * 0.2;

        // Seamless wrapping relative to player progression along the course
        const relZ = c.sprite.position.z - ballPos.z;
        if (relZ < -60) {
          c.sprite.position.z += 300;
          c.sprite.position.x = ballPos.x + (Math.random() - 0.5) * (c.isDeck ? 160 : 150);
        } else if (relZ > 240) {
          c.sprite.position.z -= 300;
        }

        // Horizontal lateral wrapping
        const relX = c.sprite.position.x - ballPos.x;
        if (relX > 110) c.sprite.position.x -= 220;
        else if (relX < -110) c.sprite.position.x += 220;
      }

      // Update Sun Flare
      this.updateSunFlare(dt);
    }

    createAmbientDust() {
      const particleCount = 280;
      const positions = new Float32Array(particleCount * 3);
      this.dustVelocities = [];

      // Generate a soft circular glow sprite
      const canvas = document.createElement('canvas');
      canvas.width = 32;
      canvas.height = 32;
      const ctx = canvas.getContext('2d');
      const gradient = ctx.createRadialGradient(16, 16, 0, 16, 16, 16);
      gradient.addColorStop(0, 'rgba(224, 242, 254, 0.95)');
      gradient.addColorStop(0.35, 'rgba(56, 189, 248, 0.5)');
      gradient.addColorStop(1, 'rgba(56, 189, 248, 0.0)');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, 32, 32);

      const particleTexture = new THREE.CanvasTexture(canvas);

      for (let i = 0; i < particleCount; i++) {
        positions[i * 3] = (Math.random() - 0.5) * 55;
        positions[i * 3 + 1] = Math.random() * 18 - 3;
        positions[i * 3 + 2] = (Math.random() - 0.5) * 70;

        this.dustVelocities.push({
          vx: (Math.random() - 0.5) * 0.15,
          vy: 0.07 + Math.random() * 0.14,
          vz: (Math.random() - 0.5) * 0.15,
          phase: Math.random() * Math.PI * 2,
          swaySpeed: 0.6 + Math.random() * 0.9
        });
      }

      const dustGeo = new THREE.BufferGeometry();
      dustGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));

      const dustMat = new THREE.PointsMaterial({
        size: 0.38,
        map: particleTexture,
        transparent: true,
        opacity: 0.35,
        blending: THREE.AdditiveBlending,
        depthWrite: false
      });

      this.dustParticles = new THREE.Points(dustGeo, dustMat);
      this.scene.add(this.dustParticles);
    }

    updateAmbientDust(dt, time) {
      if (!this.dustParticles) return;

      const positions = this.dustParticles.geometry.attributes.position.array;
      const ballPos = this.ballMesh ? this.ballMesh.position : new THREE.Vector3(0, 0, 0);

      const radiusX = 28;
      const radiusZ = 35;
      const minY = -3;
      const maxY = 15;

      for (let i = 0; i < this.dustVelocities.length; i++) {
        const vel = this.dustVelocities[i];
        const idx = i * 3;

        // Subtle gentle drift and sway
        positions[idx] += (vel.vx + Math.sin(time * vel.swaySpeed + vel.phase) * 0.06) * dt;
        positions[idx + 1] += vel.vy * dt;
        positions[idx + 2] += (vel.vz + Math.cos(time * vel.swaySpeed + vel.phase) * 0.06) * dt;

        // Wrap vertically
        if (positions[idx + 1] > maxY) {
          positions[idx + 1] = minY;
        }

        // Keep smoothly surrounding the player along the bridge
        const dx = positions[idx] - ballPos.x;
        const dz = positions[idx + 2] - ballPos.z;

        if (dx > radiusX) positions[idx] -= radiusX * 2;
        else if (dx < -radiusX) positions[idx] += radiusX * 2;

        if (dz > radiusZ) positions[idx + 2] -= radiusZ * 2;
        else if (dz < -radiusZ) positions[idx + 2] += radiusZ * 2;
      }

      this.dustParticles.geometry.attributes.position.needsUpdate = true;
    }

    createGlassBall() {
      const ballGroup = new THREE.Group();

      // Translucent Glass Outer Sphere
      const glassGeo = new THREE.SphereGeometry(this.ballRadius, 32, 32);
      const glassMat = new THREE.MeshPhysicalMaterial({
        color: 0xE0F2FE,
        transmission: 0.9,
        opacity: 1,
        transparent: true,
        roughness: 0.08,
        metalness: 0.12,
        ior: 1.52,
        reflectivity: 0.8,
        clearcoat: 1.0,
        clearcoatRoughness: 0.1
      });
      const outerBall = new THREE.Mesh(glassGeo, glassMat);
      outerBall.castShadow = true;
      ballGroup.add(outerBall);

      // Inner Glowing Crystal Core
      const coreGeo = new THREE.SphereGeometry(this.ballRadius * 0.45, 16, 16);
      const coreMat = new THREE.MeshBasicMaterial({
        color: 0x38BDF8,
        transparent: true,
        opacity: 0.85
      });
      const innerCore = new THREE.Mesh(coreGeo, coreMat);
      ballGroup.add(innerCore);

      this.ballMesh = ballGroup;
      this.scene.add(this.ballMesh);
    }

    // --- PROCEDURAL 3D GLASS BRIDGE GENERATION ---
    // Evaluates 3D position and orientation vectors along course coordinate `s`
    getTrackSample(s) {
      const step = 0.5;
      let x = 0;
      let z = 0;
      let yaw = 0;

      // Integrate course curvature
      for (let curS = 0; curS <= s; curS += step) {
        const kappa = this.course.curveAt(curS);
        yaw += kappa * step * 0.15;
        x += Math.sin(yaw) * step;
        z += Math.cos(yaw) * step;
      }

      // Forward tangent
      const tangent = new THREE.Vector3(Math.sin(yaw), 0, Math.cos(yaw)).normalize();
      const normal = new THREE.Vector3(0, 1, 0);
      // Binormal: points RIGHT relative to the bridge forward direction
      const binormal = new THREE.Vector3().crossVectors(tangent, normal).negate().normalize();

      // Start platform is wider (width = 8.0)
      const isStartPlatform = s < 12;
      const isFinishPlatform = s > this.course.totalLength - 10;
      const width = isStartPlatform || isFinishPlatform ? 7.5 : this.course.width;

      return {
        pos: new THREE.Vector3(x, 0, z),
        tangent: tangent,
        normal: normal,
        binormal: binormal, // Points RIGHT
        yaw: yaw,
        width: width,
        isStartPlatform: isStartPlatform,
        isFinishPlatform: isFinishPlatform
      };
    }

    checkIsGap(s, lane) {
      // Start and Finish platforms NEVER have gaps
      if (s < 14 || s > this.course.totalLength - 10) return false;

      for (let i = 0; i < this.course.gaps.length; i++) {
        const gap = this.course.gaps[i];
        if (s >= gap.sStart && s <= gap.sEnd) {
          if (lane >= gap.laneStart && lane <= gap.laneEnd) {
            return true;
          }
        }
      }
      return false;
    }

    initCourse3D() {
      if (this.bridgeGroup) {
        this.scene.remove(this.bridgeGroup);
      }
      this.bridgeGroup = new THREE.Group();
      this.checkpointMarkers = [];

      const totalLen = this.course.totalLength;
      const segmentStep = 2.0;

      // Rich Red Glass Platform Material
      const glassMat = new THREE.MeshPhysicalMaterial({
        color: 0xDC2626,             // Vibrant deep ruby red
        emissive: 0x3F0708,          // Subtle deep red internal glass warmth
        emissiveIntensity: 0.12,
        transmission: 0.45,          // Visibly glass-like with semi-transparency, easy to see against the sky
        transparent: true,
        opacity: 0.94,
        roughness: 0.04,             // Ultra-glossy, pristine glass surface
        metalness: 0.12,
        ior: 1.54,                   // High refractive index for realistic glass optics
        reflectivity: 0.92,          // Crisp reflections of sunlight and sky
        clearcoat: 1.0,              // High glossy clearcoat
        clearcoatRoughness: 0.04
      });

      // Brighter luminous red edge runners framing the platform shape
      const railMat = new THREE.MeshStandardMaterial({
        color: 0xFF2A55,             // Bright red edge highlight
        emissive: 0xEF4444,          // Radiant red border illumination
        emissiveIntensity: 0.68,
        roughness: 0.12,
        metalness: 0.75
      });

      // Starting platform solid garnet-slate base
      const startMat = new THREE.MeshStandardMaterial({
        color: 0x2A0E13,
        roughness: 0.35,
        metalness: 0.75
      });

      // Subtle transverse edge seam material for crystal tile definition
      const seamMat = new THREE.MeshStandardMaterial({
        color: 0xF87171,
        emissive: 0xEF4444,
        emissiveIntensity: 0.48,
        roughness: 0.15
      });

      for (let s = 0; s <= totalLen; s += segmentStep) {
        const p1 = this.getTrackSample(s);
        const p2 = this.getTrackSample(s + segmentStep);

        const segCenter = new THREE.Vector3().addVectors(p1.pos, p2.pos).multiplyScalar(0.5);
        const segLen = p1.pos.distanceTo(p2.pos);
        const avgWidth = (p1.width + p2.width) * 0.5;

        // Check if segment is in a gap
        const hasFullGap = this.checkIsGap(s + segmentStep * 0.5, 0) &&
                          this.checkIsGap(s + segmentStep * 0.5, -avgWidth * 0.3) &&
                          this.checkIsGap(s + segmentStep * 0.5, avgWidth * 0.3);

        if (!hasFullGap) {
          // If partial gap, render split tiles; otherwise render full tile
          const isGapLeft = this.checkIsGap(s + segmentStep * 0.5, -avgWidth * 0.35);
          const isGapRight = this.checkIsGap(s + segmentStep * 0.5, avgWidth * 0.35);

          if (isGapLeft || isGapRight) {
            // Render non-gap half
            const tileW = avgWidth * 0.48;
            const tileGeo = new THREE.BoxGeometry(tileW, 0.25, segLen * 0.95);
            const tileMesh = new THREE.Mesh(tileGeo, glassMat);
            tileMesh.castShadow = true;
            tileMesh.receiveShadow = true;

            const offsetDir = isGapLeft ? 1 : -1;
            const offsetPos = segCenter.clone().addScaledVector(p1.binormal, offsetDir * (avgWidth * 0.26));
            tileMesh.position.copy(offsetPos);
            tileMesh.rotation.y = p1.yaw;
            this.bridgeGroup.add(tileMesh);
          } else {
            // Solid full glass slab
            const slabGeo = new THREE.BoxGeometry(avgWidth, 0.25, segLen * 0.98);
            const slabMesh = new THREE.Mesh(slabGeo, p1.isStartPlatform ? startMat : glassMat);
            slabMesh.castShadow = true;
            slabMesh.receiveShadow = true;
            slabMesh.position.copy(segCenter);
            slabMesh.rotation.y = p1.yaw;
            this.bridgeGroup.add(slabMesh);
          }
        }

        // Bridge edge glowing runners (brighter, slightly wider for crisp platform shape)
        const railGeo = new THREE.BoxGeometry(0.14, 0.16, segLen);
        const leftRail = new THREE.Mesh(railGeo, railMat);
        leftRail.position.copy(segCenter).addScaledVector(p1.binormal, -avgWidth * 0.5);
        leftRail.position.y += 0.14;
        leftRail.rotation.y = p1.yaw;
        this.bridgeGroup.add(leftRail);

        const rightRail = new THREE.Mesh(railGeo, railMat);
        rightRail.position.copy(segCenter).addScaledVector(p1.binormal, avgWidth * 0.5);
        rightRail.position.y += 0.14;
        rightRail.rotation.y = p1.yaw;
        this.bridgeGroup.add(rightRail);

        // Transverse glass edge seam highlighting platform shape
        const seamGeo = new THREE.BoxGeometry(avgWidth * 0.96, 0.03, 0.08);
        const seamMesh = new THREE.Mesh(seamGeo, seamMat);
        seamMesh.position.copy(p1.pos);
        seamMesh.position.y += 0.13;
        seamMesh.rotation.y = p1.yaw;
        this.bridgeGroup.add(seamMesh);

        // Support pillar every 16 meters
        if (Math.floor(s) % 16 === 0) {
          const pillarGeo = new THREE.CylinderGeometry(0.5, 0.7, 18, 16);
          const pillarMat = new THREE.MeshStandardMaterial({ color: 0x2A151C, roughness: 0.5, metalness: 0.5 });
          const pillar = new THREE.Mesh(pillarGeo, pillarMat);
          pillar.position.copy(p1.pos);
          pillar.position.y -= 9.1;
          this.bridgeGroup.add(pillar);
        }
      }

      // Checkpoint Arches
      this.course.checkpoints.forEach((cpS, cpIndex) => {
        const cpSample = this.getTrackSample(cpS);
        const archGeo = new THREE.TorusGeometry(cpSample.width * 0.55, 0.16, 16, 32, Math.PI);
        const archMat = new THREE.MeshStandardMaterial({
          color: 0xF59E0B,
          emissive: 0xD97706,
          emissiveIntensity: 0.6,
          roughness: 0.2
        });
        const archMesh = new THREE.Mesh(archGeo, archMat);
        archMesh.position.copy(cpSample.pos);
        archMesh.position.y += 0.1;
        archMesh.rotation.y = cpSample.yaw;
        this.bridgeGroup.add(archMesh);

        this.checkpointMarkers.push({
          s: cpS,
          index: cpIndex + 1,
          mesh: archMesh
        });
      });

      // Finish Portal at totalLength
      const finishSample = this.getTrackSample(totalLen);
      const finishGeo = new THREE.TorusGeometry(finishSample.width * 0.6, 0.25, 16, 32, Math.PI);
      const finishMat = new THREE.MeshStandardMaterial({
        color: 0x10B981,
        emissive: 0x059669,
        emissiveIntensity: 0.8,
        roughness: 0.15
      });
      const finishMesh = new THREE.Mesh(finishGeo, finishMat);
      finishMesh.position.copy(finishSample.pos);
      finishMesh.rotation.y = finishSample.yaw;
      this.bridgeGroup.add(finishMesh);

      this.scene.add(this.bridgeGroup);
    }

    // --- LEVEL MANAGEMENT & RESETS ---
    startLevel(index, fromCheckpoint = false) {
      this.currentLevelIndex = index;
      this.course = COURSES[index];

      // CRITICAL RESET SAFETY: Clear all movement controls and reset speeds to 0
      this.controls.clear();

      this.state = this.createState();
      this.state.forwardSpeed = 0;
      this.state.sideSpeed = 0;

      if (fromCheckpoint && this.lastCheckpointS > 0) {
        this.state.s = this.lastCheckpointS;
        this.showBanner(`Respawned at Checkpoint (${Math.round(this.lastCheckpointS)}m)`);
      } else {
        this.lastCheckpointS = 0;
        this.state.s = 0;
        this.initCourse3D();
        this.showBanner(`${this.course.name} - Ready!`);
      }

      this.state.lane = 0;
      this.state.isFalling = false;
      this.state.fallVelocity = 0;
      this.state.fallY = 0;
      this.state.completed = false;

      this.updateBall3DPosition();
      this.updateCameraImmediate();
      this.updateHUD();
      this.closeAllModals();
    }

    restartLevel() {
      this.startLevel(this.currentLevelIndex, false);
    }

    respawnAtCheckpoint() {
      this.startLevel(this.currentLevelIndex, true);
    }

    // --- CORE MOVEMENT LOOP (EXACT USER SPECIFICATION) ---
    updateMovement(dt) {
      if (this.state.completed) return;

      const state = this.state;
      const course = this.course;
      const input = this.controls;

      // When falling, physics is handled separately
      if (state.isFalling) {
        state.fallVelocity += 18.0 * dt;
        state.fallY -= state.fallVelocity * dt;

        // Animate downward fall
        this.updateBall3DPosition();
        if (state.fallY < -15.0) {
          this.onFallComplete();
        }
        return;
      }

      // 1. Forward / Backward Input Calculation
      const forwardInput = Number(input.has('up')) - Number(input.has('down'));

      // 2. Left / Right Input Calculation
      const sideInput = Number(input.has('right')) - Number(input.has('left'));

      // 3. Forward Speed Update
      if (forwardInput === 0) {
        state.forwardSpeed = 0;
      } else {
        state.forwardSpeed += (forwardInput * 8.2 - state.forwardSpeed * 2.1) * dt;
        state.forwardSpeed = Math.max(-2.2, Math.min(course.speed, state.forwardSpeed));
      }

      // 4. Side Speed Update
      if (sideInput === 0) {
        state.sideSpeed = 0;
      } else {
        state.sideSpeed += (sideInput * 11.5 - state.sideSpeed * 3.15) * dt;
        state.sideSpeed = Math.max(-5.2, Math.min(5.2, state.sideSpeed));
      }

      // 5. Integrate Position
      state.s += state.forwardSpeed * dt;
      state.lane += state.sideSpeed * dt;

      // Prevent moving before s = 0 (before start line)
      if (state.s < 0) {
        state.s = 0;
        state.forwardSpeed = 0;
      }

      // 6. Check Checkpoints
      this.course.checkpoints.forEach((cpS, cpIndex) => {
        if (state.s >= cpS && !state.activeCheckpoints.has(cpIndex)) {
          state.activeCheckpoints.add(cpIndex);
          this.lastCheckpointS = cpS;
          state.score += 250;
          this.sound.playCheckpoint();
          this.showBanner(`Checkpoint ${cpIndex + 1} Reached!`);
          document.getElementById('checkpoint-txt').innerText = `Checkpoint ${cpIndex + 1}`;
        }
      });

      // 7. Check Level Complete
      if (state.s >= course.totalLength) {
        this.triggerVictory();
        return;
      }

      // 8. FALLING DETECTION:
      // The ball must fall ONLY when its position actually leaves the glass bridge or enters a real gap.
      const trackPoint = this.getTrackSample(state.s);
      const halfWidth = trackPoint.width * 0.5;

      const isOffEdge = Math.abs(state.lane) > halfWidth;
      const isInGap = this.checkIsGap(state.s, state.lane);

      if (isOffEdge || isInGap) {
        // Trigger falling
        state.isFalling = true;
        state.forwardSpeed = 0;
        state.sideSpeed = 0;
        this.sound.playFall();
        return;
      }

      // Update 3D position and camera
      this.updateBall3DPosition();
      this.updateCameraFollow(dt);

      // Score calculation
      state.score = Math.max(state.score, Math.floor(state.s * 10) + state.activeCheckpoints.size * 250);
      this.updateHUD();
    }

    updateBall3DPosition() {
      const track = this.getTrackSample(this.state.s);

      // Ball sits on bridge surface: track.pos + track.binormal * lane + track.normal * (ballRadius + thickness/2)
      const surfaceY = 0.125 + this.ballRadius + this.state.fallY;
      const worldPos = track.pos.clone()
        .addScaledVector(track.binormal, this.state.lane)
        .addScaledVector(track.normal, surfaceY);

      this.ballMesh.position.copy(worldPos);

      // Ball rotation from rolling:
      // Rolling forward rotates around binormal; rolling sideways rotates around tangent
      if (!this.state.isFalling) {
        const rollPitch = (this.state.forwardSpeed * 0.016) / this.ballRadius;
        const rollRoll = (this.state.sideSpeed * 0.016) / this.ballRadius;
        this.ballMesh.rotation.x += rollPitch * Math.cos(track.yaw) - rollRoll * Math.sin(track.yaw);
        this.ballMesh.rotation.z += rollPitch * Math.sin(track.yaw) + rollRoll * Math.cos(track.yaw);
      }
    }

    updateCameraImmediate() {
      const track = this.getTrackSample(this.state.s);
      const ballPos = this.ballMesh.position;

      // Position camera behind the ball along the bridge's forward direction
      const camPos = ballPos.clone()
        .addScaledVector(track.tangent, -6.5)
        .addScaledVector(track.normal, 4.2);

      this.camera.position.copy(camPos);
      const lookTarget = ballPos.clone().addScaledVector(track.tangent, 2.5);
      this.camera.lookAt(lookTarget);
    }

    updateCameraFollow(dt) {
      const track = this.getTrackSample(this.state.s);
      const ballPos = this.ballMesh.position;

      const targetCamPos = ballPos.clone()
        .addScaledVector(track.tangent, -6.5)
        .addScaledVector(track.normal, 4.2);

      // Smooth camera interpolation
      this.camera.position.lerp(targetCamPos, Math.min(1.0, dt * 10.0));

      const lookTarget = ballPos.clone().addScaledVector(track.tangent, 2.5);
      this.camera.lookAt(lookTarget);
    }

    onFallComplete() {
      document.getElementById('res-progress').innerText = `${Math.min(100, Math.round((this.state.s / this.course.totalLength) * 100))}%`;
      document.getElementById('res-score').innerText = `${this.state.score}`;
      this.openModal('modal-gameover');
    }

    triggerVictory() {
      this.state.completed = true;
      this.sound.playVictory();
      document.getElementById('vic-score').innerText = `${this.state.score + 1000}`;
      document.getElementById('vic-checkpoints').innerText = `${this.state.activeCheckpoints.size}/${this.course.checkpoints.length}`;
      this.openModal('modal-victory');
    }

    updateHUD() {
      const progress = Math.min(100, Math.round((this.state.s / this.course.totalLength) * 100));
      document.getElementById('bar-progress').style.width = `${progress}%`;
      document.getElementById('txt-progress-pct').innerText = `${progress}%`;
      document.getElementById('txt-score').innerText = `${this.state.score}`;
      document.getElementById('txt-level').innerText = `Level ${this.course.id}`;
    }

    showBanner(msg) {
      const banner = document.getElementById('banner-container');
      banner.innerHTML = `<div class="banner-msg">${msg}</div>`;
      setTimeout(() => {
        banner.innerHTML = '';
      }, 2400);
    }

    openModal(id) {
      this.closeAllModals();
      const el = document.getElementById(id);
      if (el) el.classList.add('active');
    }

    closeAllModals() {
      document.querySelectorAll('.modal-overlay').forEach(el => el.classList.remove('active'));
    }

    // --- INPUT EVENT LISTENERS (EXACT SPECIFICATION) ---
    initInputListeners() {
      // 1. TOUCH & DIRECTION BUTTONS WITH SAFE RELEASES
      const dirButtons = document.querySelectorAll('.dpad-btn');
      dirButtons.forEach(btn => {
        const dir = btn.getAttribute('data-dir');
        if (!dir) return;

        // Pointerdown: activate direction
        btn.addEventListener('pointerdown', (e) => {
          e.preventDefault();
          this.sound.init();
          this.controls.add(dir);
          btn.classList.add('active');
        });

        // Pointerup: release direction
        btn.addEventListener('pointerup', (e) => {
          e.preventDefault();
          this.controls.delete(dir);
          btn.classList.remove('active');
        });

        // Pointercancel: release direction
        btn.addEventListener('pointercancel', (e) => {
          e.preventDefault();
          this.controls.delete(dir);
          btn.classList.remove('active');
        });

        // Pointerleave: release direction
        btn.addEventListener('pointerleave', (e) => {
          e.preventDefault();
          this.controls.delete(dir);
          btn.classList.remove('active');
        });
      });

      // 2. GLOBAL POINTERUP & POINTERCANCEL SAFETY HANDLERS
      const releaseControls = () => {
        for (const direction of ['up', 'down', 'left', 'right']) {
          this.controls.delete(direction);
        }
        dirButtons.forEach(b => b.classList.remove('active'));
      };

      window.addEventListener('pointerup', releaseControls);
      window.addEventListener('pointercancel', releaseControls);
      window.addEventListener('blur', releaseControls);

      // 3. KEYBOARD LISTENERS (Arrow Keys & WASD)
      window.addEventListener('keydown', (e) => {
        this.sound.init();
        if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
          this.controls.add('up');
          document.getElementById('dpad-up')?.classList.add('active');
        } else if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') {
          this.controls.add('down');
          document.getElementById('dpad-down')?.classList.add('active');
        } else if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
          this.controls.add('left');
          document.getElementById('dpad-left')?.classList.add('active');
        } else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
          this.controls.add('right');
          document.getElementById('dpad-right')?.classList.add('active');
        }
      });

      window.addEventListener('keyup', (e) => {
        if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
          this.controls.delete('up');
          document.getElementById('dpad-up')?.classList.remove('active');
        } else if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') {
          this.controls.delete('down');
          document.getElementById('dpad-down')?.classList.remove('active');
        } else if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
          this.controls.delete('left');
          document.getElementById('dpad-left')?.classList.remove('active');
        } else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
          this.controls.delete('right');
          document.getElementById('dpad-right')?.classList.remove('active');
        }
      });

      // Window resize
      window.addEventListener('resize', () => {
        const w = window.innerWidth;
        const h = window.innerHeight;
        this.camera.aspect = w / h;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(w, h);
      });

      // Main Animation Loop
      let lastTime = performance.now();
      const animate = (time) => {
        requestAnimationFrame(animate);
        const dt = Math.min(0.1, (time - lastTime) / 1000);
        lastTime = time;

        this.updateMovement(dt);
        this.updateAmbientDust(dt, time * 0.001);
        this.updateSkyAndClouds(dt, time * 0.001);
        this.renderer.render(this.scene, this.camera);
      };
      requestAnimationFrame(animate);
    }

    // --- UI BUTTONS & MODALS ---
    initDOM() {
      // Pause button
      document.getElementById('btn-pause').addEventListener('click', () => {
        this.sound.init();
        this.openModal('modal-pause');
      });

      document.getElementById('btn-resume').addEventListener('click', () => {
        this.closeAllModals();
      });

      document.getElementById('btn-pause-restart').addEventListener('click', () => {
        this.restartLevel();
      });

      document.getElementById('btn-pause-checkpoint').addEventListener('click', () => {
        this.respawnAtCheckpoint();
      });

      // Level select
      document.getElementById('level-display').addEventListener('click', () => {
        this.populateLevelGrid();
        this.openModal('modal-levels');
      });

      document.getElementById('btn-levels').addEventListener('click', () => {
        this.populateLevelGrid();
        this.openModal('modal-levels');
      });

      document.getElementById('btn-close-levels').addEventListener('click', () => {
        this.closeAllModals();
      });

      // Restart button
      document.getElementById('btn-restart').addEventListener('click', () => {
        this.sound.init();
        this.restartLevel();
      });

      // Game Over buttons
      document.getElementById('btn-checkpoint-respawn').addEventListener('click', () => {
        this.sound.init();
        this.respawnAtCheckpoint();
      });

      document.getElementById('btn-retry').addEventListener('click', () => {
        this.sound.init();
        this.restartLevel();
      });

      // Victory buttons
      document.getElementById('btn-next-level').addEventListener('click', () => {
        this.sound.init();
        const nextIdx = (this.currentLevelIndex + 1) % COURSES.length;
        this.startLevel(nextIdx, false);
      });

      document.getElementById('btn-menu-from-vic').addEventListener('click', () => {
        this.populateLevelGrid();
        this.openModal('modal-levels');
      });
    }

    populateLevelGrid() {
      const grid = document.getElementById('level-list');
      grid.innerHTML = '';
      COURSES.forEach((course, idx) => {
        const tile = document.createElement('div');
        tile.className = `level-tile ${idx === this.currentLevelIndex ? 'active' : ''}`;
        tile.innerHTML = `
          <div class="level-number">${course.id}</div>
          <div style="font-size: 10px; color: #94A3B8; text-align: center; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 60px;">${course.name}</div>
          <div class="level-stars">★★★</div>
        `;
        tile.addEventListener('click', () => {
          this.startLevel(idx, false);
        });
        grid.appendChild(tile);
      });
    }
  }

  // Launch when DOM is ready
  window.addEventListener('DOMContentLoaded', () => {
    window.game = new GameWorld();
  });
})();
